import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sensors_plus/sensors_plus.dart';

class GamePage extends StatefulWidget {
  @override
  _GamePageState createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  List<String> words = ['Manzana', 'Platano', 'Uva'];
  int currentWordIndex = 0;
  Timer? _timer;
  int _start = 60;
  double _shakeThreshold = 15.0;
  double _lastX = 0, _lastY = 0, _lastZ = 0;
  int _shakeCount = 0;
  int _shakeResetTime = 500;

  @override
  void initState() {
    super.initState();
    startTimer();
    _initializeShakeDetection();
  }

  void startTimer() {
    const oneSec = const Duration(seconds: 1);
    _timer = new Timer.periodic(
      oneSec,
          (Timer timer) {
        if (_start == 0) {
          setState(() {
            timer.cancel();
          });
        } else {
          setState(() {
            _start--;
          });
        }
      },
    );
  }

  void _initializeShakeDetection() {
    accelerometerEvents.listen((AccelerometerEvent event) {
      double x = event.x;
      double y = event.y;
      double z = event.z;

      double deltaX = (x - _lastX).abs();
      double deltaY = (y - _lastY).abs();
      double deltaZ = (z - _lastZ).abs();

      _lastX = x;
      _lastY = y;
      _lastZ = z;

      if (deltaX > _shakeThreshold || deltaY > _shakeThreshold || deltaZ > _shakeThreshold) {
        _shakeCount++;
        if (_shakeCount > 2) {
          nextWord();
          _shakeCount = 0;
        }
      }

      Timer(Duration(milliseconds: _shakeResetTime), () {
        _shakeCount = 0;
      });
    });
  }

  void nextWord() {
    setState(() {
      if (currentWordIndex < words.length - 1) {
        currentWordIndex++;
      } else {
        currentWordIndex = 0;
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Charaditas'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue, Colors.purple],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                words[currentWordIndex],
                style: TextStyle(
                  fontSize: 50,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  shadows: [
                    Shadow(
                      blurRadius: 10.0,
                      color: Colors.black,
                      offset: Offset(5.0, 5.0),
                    ),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 40),
              Text(
                'Tiempo restante: $_start segundos',
                style: TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.w500,
                  color: Colors.yellow,
                ),
              ),
              SizedBox(height: 40),
              ElevatedButton(
                onPressed: nextWord,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                  textStyle: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                child: Text('Siguiente palabra'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}